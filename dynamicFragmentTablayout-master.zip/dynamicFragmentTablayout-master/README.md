# dynamicFragmentTablayout
Android: Dynamic fragment Adding in TabLayout

Android: Dynamic fragment Adding in TabLayout

We usually used Dynamic fragment Adding in TabLayout , If all Fragments UI same in TabLayout.

VideoDemo:
https://youtu.be/NMGSZj4XrEk
